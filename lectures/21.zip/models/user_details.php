<?php

include_once 'dbs.php';

class user_details {


	function __construct() 
	{
		$dbs = New dbs();

		$conn = $dbs ->connect();

	}


	public function getStudDetails($id)
	{
		$query= "SELECT * FROM coursemgs.students WHERE userid= '".$id."';";
				$result = mysql_query($query);

		if($result)
		{
			if(mysql_num_rows($result) > 0)
			{
				return $result;
			}
			
			return 0; // no results found
		
		}

		return 0;

	}

	public function getName($userid)
	{
		$query = "select name from coursemgs.students 
			where userid='".$userid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return mysql_fetch_array($result);



	}

	public function getProgram($userid)
	{
		$query = "select program from coursemgs.students 
			where userid='".$userid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return mysql_fetch_array($result);



	}

	public function getBatch($userid)
	{
		$query = "select batch from coursemgs.students 
			where userid='".$userid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return mysql_fetch_array($result);



	}


	public function getDept($userid)
	{
		$query = "select department from coursemgs.students 
			where userid='".$userid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return mysql_fetch_array($result);



	}

	public function getRollNo($userid)
	{
		$query = "select name from coursemgs.students 
			where userid='".$userid."';";
					$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return mysql_fetch_array($result);



	}





	
}



?>