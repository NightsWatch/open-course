<?php

require 'dbs.php';

class courses {

	function __construct() {
		$dbs = New dbs();

		$conn = $dbs ->connect();

	}


	public function getCourseInfo($courseid) {
		//$mysql = New mysql();
		$query = "select * from 'coursemgs'.'courses' where 'courseid'= '".$courseid."' ;";
		$result=mysql_query($query);

		if(!$result) {
    		echo "Database query failed: " . mysql_error()
		}
		return $result;
	}


	public function getStudentCourses($userid) {
		//$mysql = New mysql();
		$query = "select * from 'coursemgs'.'courses' where 'courseid' in (select 'courseid' from 'coursemsgs'.'course-stud-registration' where 'studentid'='".$userid."');";
		$result=mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return $result;
	}

	public function getCourseStudents($courseid) {
		$query = "select * from 'coursemgs'.'students' where 'userid' in (select 'studentid' from 'coursemsgs'.'course-stud-registration' where 'courseid'='".$courseid."');";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return $result;
	}

	public function getCourseTAs($courseid) {
		$query = "select * from coursemgs.student where userid in (select 'taid' from 'course-ta-allotment' where 'courseid'='".$courseid."');";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return $result;
	}

	public function getCourseAssignments($courseid) {
		$query = "select * from coursemgs.assignments where courseid='".$courseid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return $result;
	}

	public function getCourseName($courseid)
	{
		$query = "select coursename from coursemgs.courses where courseid='".$courseid."';";
		$result = mysql_query($query);

		if($result)
		{
			if(mysql_num_rows($result) > 0)
			{
				return $result;
			}
			
			return 0;
		
		}

    	
	}

	public function getCourseForumThreads($courseid) {
		$query="select * from coursemgs.forums where courseid='".$courseid."';";
		$result = mysql_query($query);

		if(!$result) {
    		die("Database query failed: " . mysql_error());
		}
		return $result;
	}


	public function getInstructors($courseid) {
		$query="select name from coursemgs.faculty where userid in ( select facultyid from coursemgs.course-faculty-allotment where courseid='".$courseid."');";
		$result = mysql_query($query);

		if(!$result) {
    		echo "Database query failed: " . mysql_error();
		}
		return $result;
	}

}


?>