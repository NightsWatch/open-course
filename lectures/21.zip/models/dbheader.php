<?php 

define('HOSTNAME', '127.0.0.1');
define('DBUSER', 'root');
define('DBPASS', 'mysql');
define('DBNAME', 'coursemgs');

define('USERS_TBL', 'users');
define('STUD_TBL', 'students');
define('FAC_TBL', 'faculty');

define('ASSNS_TBL', 'assignments');
define('SUBMS_TBL', 'assignsubmissions');
define('LECTURES_TBL', 'lectures')

 ?>
